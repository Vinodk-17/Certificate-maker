import io
import json
import shutil
import tempfile
import zipfile
from pathlib import Path

import pandas as pd
import streamlit as st

from services.certificate_service import (
    detect_placeholders,
    generate_certificates,
    make_preview_image,
)
from services.database import (
    init_db,
    list_templates,
    save_template_record,
    delete_template_record,
)

APP_DIR = Path(__file__).resolve().parent
TEMPLATE_DIR = APP_DIR / "templates"
GENERATED_DIR = APP_DIR / "generated"
TEMP_DIR = APP_DIR / "temp"

for directory in (TEMPLATE_DIR, GENERATED_DIR, TEMP_DIR):
    directory.mkdir(parents=True, exist_ok=True)

init_db()

st.set_page_config(
    page_title="Certificate Maker",
    page_icon="🎓",
    layout="wide",
)

st.title("🎓 Certificate Maker")
st.caption("Upload a PowerPoint template, add recipient data, preview, and generate certificate PDFs.")

with st.expander("How to prepare your PowerPoint template", expanded=False):
    st.markdown(
        """
Use a one-slide `.pptx` file and place fields inside double curly brackets.

Example:

- `{{name}}`
- `{{course}}`
- `{{date}}`
- `{{certificate_id}}`

The application replaces these placeholders with recipient data.
"""
    )

tab_template, tab_data, tab_generate = st.tabs(
    ["1. Template", "2. Recipient Data", "3. Preview & Generate"]
)

if "selected_template_path" not in st.session_state:
    st.session_state.selected_template_path = None
if "selected_template_name" not in st.session_state:
    st.session_state.selected_template_name = None
if "recipients_df" not in st.session_state:
    st.session_state.recipients_df = pd.DataFrame()

with tab_template:
    st.subheader("Choose a certificate template")

    existing_templates = list_templates()
    existing_names = [item["name"] for item in existing_templates]

    left, right = st.columns([1, 1])

    with left:
        if existing_names:
            selected_name = st.selectbox(
                "Saved templates",
                ["Select a template"] + existing_names,
            )
            if selected_name != "Select a template":
                selected = next(
                    item for item in existing_templates if item["name"] == selected_name
                )
                st.session_state.selected_template_name = selected["name"]
                st.session_state.selected_template_path = selected["file_path"]

                placeholders = json.loads(selected["placeholders"])
                st.success(f"Selected: {selected_name}")
                st.write("Detected placeholders:", ", ".join(placeholders) or "None")

                if st.button("Delete selected template", type="secondary"):
                    try:
                        Path(selected["file_path"]).unlink(missing_ok=True)
                        delete_template_record(selected["id"])
                        st.session_state.selected_template_name = None
                        st.session_state.selected_template_path = None
                        st.rerun()
                    except Exception as exc:
                        st.error(f"Could not delete template: {exc}")
        else:
            st.info("No templates saved yet.")

    with right:
        uploaded_template = st.file_uploader(
            "Upload a new PPTX template",
            type=["pptx"],
            accept_multiple_files=False,
        )
        template_name = st.text_input(
            "Template name",
            placeholder="Example: Course Completion",
        )

        if uploaded_template and st.button("Save template", type="primary"):
            try:
                if not template_name.strip():
                    st.error("Enter a template name.")
                else:
                    safe_name = "".join(
                        ch for ch in template_name.strip() if ch.isalnum() or ch in (" ", "-", "_")
                    ).strip()
                    destination = TEMPLATE_DIR / f"{safe_name}.pptx"
                    destination.write_bytes(uploaded_template.getbuffer())

                    placeholders = detect_placeholders(destination)
                    if not placeholders:
                        destination.unlink(missing_ok=True)
                        st.error("No placeholders were found. Add fields such as {{name}}.")
                    else:
                        save_template_record(
                            name=safe_name,
                            file_path=str(destination),
                            placeholders=placeholders,
                        )
                        st.session_state.selected_template_name = safe_name
                        st.session_state.selected_template_path = str(destination)
                        st.success(
                            "Template saved. Detected: "
                            + ", ".join(placeholders)
                        )
                        st.rerun()
            except Exception as exc:
                st.error(f"Template upload failed: {exc}")

with tab_data:
    st.subheader("Add recipient data")

    data_method = st.radio(
        "Choose input method",
        ["Upload Excel or CSV", "Manual entry"],
        horizontal=True,
    )

    if data_method == "Upload Excel or CSV":
        uploaded_data = st.file_uploader(
            "Upload recipient data",
            type=["xlsx", "xls", "csv"],
            accept_multiple_files=False,
        )

        if uploaded_data:
            try:
                if uploaded_data.name.lower().endswith(".csv"):
                    df = pd.read_csv(uploaded_data)
                else:
                    df = pd.read_excel(uploaded_data)

                df.columns = [
                    str(column).strip().lower().replace(" ", "_")
                    for column in df.columns
                ]
                df = df.fillna("")

                st.session_state.recipients_df = df
                st.success(f"Loaded {len(df)} recipient rows.")
                st.dataframe(df, use_container_width=True)
            except Exception as exc:
                st.error(f"Could not read the file: {exc}")

        sample_df = pd.DataFrame(
            [
                {
                    "name": "Rahul Sharma",
                    "course": "Generative AI",
                    "date": "27 July 2026",
                },
                {
                    "name": "Priya Mehta",
                    "course": "Data Science",
                    "date": "27 July 2026",
                },
            ]
        )
        sample_buffer = io.BytesIO()
        with pd.ExcelWriter(sample_buffer, engine="openpyxl") as writer:
            sample_df.to_excel(writer, index=False, sheet_name="Recipients")
        sample_buffer.seek(0)

        st.download_button(
            "Download sample Excel",
            data=sample_buffer,
            file_name="sample_recipients.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )

    else:
        st.write("Enter one or more recipients directly.")

        default_df = (
            st.session_state.recipients_df
            if not st.session_state.recipients_df.empty
            else pd.DataFrame(
                [{"name": "", "course": "", "date": ""}]
            )
        )

        edited_df = st.data_editor(
            default_df,
            num_rows="dynamic",
            use_container_width=True,
        )

        if st.button("Save manual data"):
            edited_df = edited_df.fillna("")
            non_empty = edited_df[
                edited_df.astype(str).apply(
                    lambda row: any(value.strip() for value in row), axis=1
                )
            ]
            st.session_state.recipients_df = non_empty
            st.success(f"Saved {len(non_empty)} recipient rows.")

with tab_generate:
    st.subheader("Preview and generate")

    template_path = st.session_state.selected_template_path
    recipients_df = st.session_state.recipients_df

    if not template_path:
        st.warning("Select or upload a template first.")
    elif recipients_df.empty:
        st.warning("Upload or enter recipient data first.")
    else:
        placeholders = detect_placeholders(Path(template_path))
        columns = list(recipients_df.columns)

        st.write("Template fields:", ", ".join(placeholders))
        st.write("Data columns:", ", ".join(columns))

        missing_fields = [
            field for field in placeholders
            if field != "certificate_id" and field not in columns
        ]

        if missing_fields:
            st.error(
                "Missing matching data columns: " + ", ".join(missing_fields)
            )
            st.info(
                "Rename your Excel columns to match the PowerPoint placeholders."
            )
        else:
            preview_data = recipients_df.iloc[0].to_dict()
            preview_data["certificate_id"] = "CERT-PREVIEW-001"

            preview_col, action_col = st.columns([2, 1])

            with preview_col:
                try:
                    preview_path = make_preview_image(
                        template_path=Path(template_path),
                        recipient_data=preview_data,
                        temp_dir=TEMP_DIR,
                    )
                    st.image(
                        str(preview_path),
                        caption="Preview generated from the first recipient row",
                        use_container_width=True,
                    )
                except Exception as exc:
                    st.warning(
                        "Preview could not be generated. "
                        "PDF generation may still work if LibreOffice is installed."
                    )
                    st.code(str(exc))

            with action_col:
                st.metric("Recipients", len(recipients_df))
                st.metric("Template", st.session_state.selected_template_name or "Uploaded")

                if len(recipients_df) > 500:
                    st.error("The lightweight version supports up to 500 rows.")
                elif st.button(
                    "Generate certificate PDFs",
                    type="primary",
                    use_container_width=True,
                ):
                    progress = st.progress(0)
                    status = st.empty()

                    output_dir = GENERATED_DIR / next(
                        tempfile._get_candidate_names()
                    )
                    output_dir.mkdir(parents=True, exist_ok=True)

                    def progress_callback(current: int, total: int, message: str):
                        progress.progress(current / max(total, 1))
                        status.write(message)

                    try:
                        pdfs, errors = generate_certificates(
                            template_path=Path(template_path),
                            recipients=recipients_df.to_dict(orient="records"),
                            output_dir=output_dir,
                            progress_callback=progress_callback,
                        )

                        zip_path = output_dir / "certificates.zip"
                        with zipfile.ZipFile(
                            zip_path, "w", compression=zipfile.ZIP_DEFLATED
                        ) as archive:
                            for pdf in pdfs:
                                archive.write(pdf, arcname=Path(pdf).name)

                            if errors:
                                error_df = pd.DataFrame(errors)
                                error_csv = error_df.to_csv(index=False).encode("utf-8")
                                archive.writestr("errors.csv", error_csv)

                        progress.progress(1.0)
                        status.success(
                            f"Finished: {len(pdfs)} generated, {len(errors)} failed."
                        )

                        st.download_button(
                            "Download certificate ZIP",
                            data=zip_path.read_bytes(),
                            file_name="certificates.zip",
                            mime="application/zip",
                            use_container_width=True,
                        )

                        if errors:
                            st.error(f"{len(errors)} rows failed.")
                            st.dataframe(pd.DataFrame(errors), use_container_width=True)

                    except Exception as exc:
                        st.error(f"Generation failed: {exc}")
