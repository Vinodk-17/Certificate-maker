# Certificate Maker

A lightweight Streamlit application for creating PDF certificates from PowerPoint templates.

## Features

- Upload and save multiple `.pptx` templates
- Detect placeholders such as `{{name}}`, `{{course}}`, and `{{date}}`
- Upload Excel or CSV recipient data
- Enter recipient data manually
- Preview the first certificate
- Generate up to 500 certificate PDFs
- Download all certificates as a ZIP
- Export failed rows in `errors.csv`

## Template rules

1. Use a one-slide PowerPoint certificate.
2. Add placeholders such as:

```text
{{name}}
{{course}}
{{date}}
{{certificate_id}}
```

3. Keep each placeholder inside a normal text box or table cell.
4. Use fonts installed on the machine running the app.

## Local setup

### 1. Install Python packages

```bash
pip install -r requirements.txt
```

### 2. Install LibreOffice

LibreOffice is required for PPTX-to-PDF conversion.

- Windows: install LibreOffice from its official installer.
- Ubuntu/Debian:

```bash
sudo apt-get install libreoffice
```

### 3. Run the app

```bash
streamlit run app.py
```

Open:

```text
http://localhost:8501
```

## Docker setup

```bash
docker compose up --build
```

Open:

```text
http://localhost:8501
```

## Sample Excel columns

```text
name | course | date
```

The Excel column names must match the PowerPoint placeholders.

## Recommended initial limits

- One-slide templates
- Maximum 500 recipients per batch
- Maximum 15 MB PowerPoint file
- Text placeholders only
- Local SQLite storage
