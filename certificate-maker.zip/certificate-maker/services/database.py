import json
import sqlite3
from pathlib import Path

DB_PATH = Path(__file__).resolve().parent.parent / "database.db"


def get_connection():
    connection = sqlite3.connect(DB_PATH)
    connection.row_factory = sqlite3.Row
    return connection


def init_db():
    with get_connection() as connection:
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS templates (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL,
                file_path TEXT NOT NULL,
                placeholders TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        connection.commit()


def save_template_record(name: str, file_path: str, placeholders: list[str]):
    with get_connection() as connection:
        connection.execute(
            """
            INSERT INTO templates (name, file_path, placeholders)
            VALUES (?, ?, ?)
            ON CONFLICT(name) DO UPDATE SET
                file_path = excluded.file_path,
                placeholders = excluded.placeholders
            """,
            (name, file_path, json.dumps(placeholders)),
        )
        connection.commit()


def list_templates():
    with get_connection() as connection:
        rows = connection.execute(
            "SELECT * FROM templates ORDER BY created_at DESC"
        ).fetchall()
    return [dict(row) for row in rows]


def delete_template_record(template_id: int):
    with get_connection() as connection:
        connection.execute(
            "DELETE FROM templates WHERE id = ?",
            (template_id,),
        )
        connection.commit()
