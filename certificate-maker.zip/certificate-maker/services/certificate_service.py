import re
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Callable, Any
from uuid import uuid4

import fitz
from pptx import Presentation
from pptx.enum.shapes import MSO_SHAPE_TYPE


PLACEHOLDER_PATTERN = re.compile(r"\{\{\s*([a-zA-Z0-9_]+)\s*\}\}")


class CertificateError(Exception):
    pass


def _iter_shapes(shapes):
    for shape in shapes:
        yield shape
        if shape.shape_type == MSO_SHAPE_TYPE.GROUP:
            yield from _iter_shapes(shape.shapes)


def _shape_text(shape) -> str:
    if getattr(shape, "has_text_frame", False):
        return "\n".join(
            "".join(run.text for run in paragraph.runs)
            for paragraph in shape.text_frame.paragraphs
        )

    if getattr(shape, "has_table", False):
        values = []
        for row in shape.table.rows:
            for cell in row.cells:
                values.append(cell.text)
        return "\n".join(values)

    return ""


def detect_placeholders(template_path: Path) -> list[str]:
    presentation = Presentation(str(template_path))
    placeholders = set()

    for slide in presentation.slides:
        for shape in _iter_shapes(slide.shapes):
            placeholders.update(
                PLACEHOLDER_PATTERN.findall(_shape_text(shape))
            )

    return sorted(placeholders)


def _replace_in_paragraph(paragraph, values: dict[str, Any]):
    full_text = "".join(run.text for run in paragraph.runs)

    if not full_text:
        return

    updated = full_text
    for key, value in values.items():
        updated = re.sub(
            r"\{\{\s*" + re.escape(str(key)) + r"\s*\}\}",
            str(value),
            updated,
        )

    if updated == full_text:
        return

    if paragraph.runs:
        paragraph.runs[0].text = updated
        for run in paragraph.runs[1:]:
            run.text = ""
    else:
        paragraph.text = updated


def render_pptx(
    template_path: Path,
    output_path: Path,
    values: dict[str, Any],
):
    presentation = Presentation(str(template_path))

    for slide in presentation.slides:
        for shape in _iter_shapes(slide.shapes):
            if getattr(shape, "has_text_frame", False):
                for paragraph in shape.text_frame.paragraphs:
                    _replace_in_paragraph(paragraph, values)

            if getattr(shape, "has_table", False):
                for row in shape.table.rows:
                    for cell in row.cells:
                        for paragraph in cell.text_frame.paragraphs:
                            _replace_in_paragraph(paragraph, values)

    output_path.parent.mkdir(parents=True, exist_ok=True)
    presentation.save(str(output_path))


def find_libreoffice() -> str:
    candidates = [
        shutil.which("libreoffice"),
        shutil.which("soffice"),
        r"C:\Program Files\LibreOffice\program\soffice.exe",
        r"C:\Program Files (x86)\LibreOffice\program\soffice.exe",
    ]

    for candidate in candidates:
        if candidate and Path(candidate).exists():
            return str(candidate)

    raise CertificateError(
        "LibreOffice was not found. Install LibreOffice and restart the app."
    )


def convert_pptx_to_pdf(
    pptx_path: Path,
    output_dir: Path,
    timeout_seconds: int = 90,
) -> Path:
    output_dir.mkdir(parents=True, exist_ok=True)
    office_binary = find_libreoffice()

    profile_dir = Path(tempfile.mkdtemp(prefix="lo_profile_"))
    command = [
        office_binary,
        f"-env:UserInstallation=file:///{profile_dir.as_posix()}",
        "--headless",
        "--convert-to",
        "pdf",
        "--outdir",
        str(output_dir),
        str(pptx_path),
    ]

    try:
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
            check=False,
        )
    finally:
        shutil.rmtree(profile_dir, ignore_errors=True)

    if result.returncode != 0:
        raise CertificateError(
            result.stderr.strip() or result.stdout.strip() or "PDF conversion failed."
        )

    pdf_path = output_dir / f"{pptx_path.stem}.pdf"
    if not pdf_path.exists():
        raise CertificateError("LibreOffice did not create the expected PDF.")

    return pdf_path


def make_preview_image(
    template_path: Path,
    recipient_data: dict[str, Any],
    temp_dir: Path,
) -> Path:
    preview_dir = temp_dir / f"preview_{uuid4().hex[:8]}"
    preview_dir.mkdir(parents=True, exist_ok=True)

    pptx_path = preview_dir / "preview.pptx"
    render_pptx(template_path, pptx_path, recipient_data)

    pdf_path = convert_pptx_to_pdf(pptx_path, preview_dir)

    document = fitz.open(pdf_path)
    if document.page_count == 0:
        raise CertificateError("The preview PDF contains no pages.")

    page = document[0]
    pixmap = page.get_pixmap(matrix=fitz.Matrix(1.5, 1.5), alpha=False)
    image_path = preview_dir / "preview.png"
    pixmap.save(str(image_path))
    document.close()

    return image_path


def safe_filename(value: str, fallback: str) -> str:
    cleaned = re.sub(r"[^a-zA-Z0-9_-]+", "_", value.strip())
    return cleaned[:80] or fallback


def generate_certificates(
    template_path: Path,
    recipients: list[dict[str, Any]],
    output_dir: Path,
    progress_callback: Callable[[int, int, str], None] | None = None,
):
    pptx_dir = output_dir / "pptx"
    pdf_dir = output_dir / "pdf"

    pptx_dir.mkdir(parents=True, exist_ok=True)
    pdf_dir.mkdir(parents=True, exist_ok=True)

    generated_pdfs = []
    errors = []
    total = len(recipients)

    for index, recipient in enumerate(recipients, start=1):
        try:
            certificate_id = f"CERT-{uuid4().hex[:10].upper()}"
            values = {
                key: "" if value is None else value
                for key, value in recipient.items()
            }
            values["certificate_id"] = certificate_id

            recipient_name = str(
                values.get("name")
                or values.get("recipient_name")
                or f"recipient_{index}"
            )
            file_stem = f"{index:04d}_{safe_filename(recipient_name, str(index))}"

            pptx_path = pptx_dir / f"{file_stem}.pptx"
            render_pptx(template_path, pptx_path, values)

            pdf_path = convert_pptx_to_pdf(pptx_path, pdf_dir)
            generated_pdfs.append(str(pdf_path))

        except Exception as exc:
            errors.append(
                {
                    "row": index,
                    "name": recipient.get("name", ""),
                    "error": str(exc),
                }
            )

        if progress_callback:
            progress_callback(
                index,
                total,
                f"Processing {index} of {total}",
            )

    return generated_pdfs, errors
